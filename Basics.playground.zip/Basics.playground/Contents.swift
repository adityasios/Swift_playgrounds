/*
 INTRO
 1. Swift is a new programming language for
 iOS,
 macOS,
 watchOS, and
 tvOS app development
 
 
 2.Swift provide following types
 Int for integer
 Double for double
 Float for float
 Bool for Boolean
 Collection Types - Array , Set ,Dictionary
 
 
 */


/*
 Constants & Variables
 associate a name (such as maximumNumberOfLoginAttempts or welcomeMessage) with a value of particular type (such as string "welcome")
 constant - value of constant cannot be chnaged once it is set (use let keyword)
 variable - can be set to different value in future (use var keyword)
 */

//Declaring Constants & Variables
let maximumNumberOfLoginAttempts = 10
var currentloginAttempt = 3

//Type Annotation
var welcomeMsg : String //Declare a variable called welcomeMessage that is of type String.
var a,b,c :String

//Naming Constants & Variables
//Constant and variable names can contain almost any character, including Unicode characters:

let π = 3.14159
let 你好 = "你好世界"
let 🐶🐮 = "dogcow"

/*
 cannot contains
 whitespace character
 mathematical symbol
 arrows, private-use Unicode scalar values, or line- and box-drawing characters.
 Nor can they begin with a number, although numbers may be included elsewhere within the name
 */


//Printing Constants & Variables
//print(_:separator:terminator:) function
print(maximumNumberOfLoginAttempts)
print("attempts done by me \(maximumNumberOfLoginAttempts)")  //string interpolation




/*
 Integers
 Integers are whole numbers with no fractional component, such as 42 and -23
 Integers are either signed (positive, zero, or negative) or unsigned (positive or zero)
 Swift provides signed and unsigned integers in 8, 16, 32, and 64 bit forms.
 UInt8 - 8-bit unsigned integer type
 Int32  -32 bit signed integer type
 */

//Integer Bound
print("UInt8 min \(UInt8.min) & max \(UInt8.max)")
print("Int8 min \(Int8.min) & max \(Int8.max)")


/*
 //Int
 which has the same size as the current platform’s native word size:
 On a 32-bit platform, Int is the same size as Int32.
 On a 64-bit platform, Int is the same size as Int64.
 */

print("Int min \(Int.min) & max \(Int.max)")
//Similarly there unsigned version - UInt

/*Floating-Point Numbers
 Floating-Point Numbers numbers with fractional components such as 3.123445 and -274.67
 Swift provides two signed floating-point number types:
 Double represents a 64-bit floating-point number - precision of at least 15 decimal digits
 Float represents a 32-bit floating-point number - precision of at least 6 decimal digits
 
 Type Safety - Swift is a type-safe language.
 Type Check - Because Swift is type safe, it performs type checks when compiling your code and flags any mismatched types as errors.
 Type Inference
 1.Type-checking helps you avoid errors when you’re working with different types of values. However, this doesn’t mean that you have to specify the type of every constant and variable that you declare.
 2.Type inference enables a compiler to deduce the type of a particular expression automatically when it compiles your code, simply by examining the values you provide.
 3.literal (literal value) - A literal value is a value that appears directly in your source code, such as 42 and 3.14159 in the examples below.
 */

let const = 42
let pi = 3.14159
//pi is inferred to be of type Double (Swift always chosse Double (rather Float)

let anotherPi = 3 + 0.14159 //anotherPi is inferred to be of type Double



/*Numeric Literals
 Integer literals can be written as:
 A decimal number, with no prefix
 A binary number, with a 0b prefix
 A octal number, with a 0o prefix
 A hexadecimal number, with a 0x prefix
 */

let decimalInteger = 17
let binaryInteger = 0b10001 //17 in binary notation
let octalInteger = 0o21  //17 in octal notation
let hexadecimalInteger = 0x11     // 17 in hexadecimal notation

/*Floating point literal
 Floating-point literals can be decimal (with no prefix), or hexadecimal (with a 0x prefix).
 */

let decimalDouble = 12.1875
let exponentDouble = 1.25e2 // 1.25 x 10∧2
let expDouble = 1.25e-22 // 1.25 x 10∧-2



let hexDouble = 0xC.3p3 //  0xC.3 x 2∧3
let hexDoublePower = 0xC.3p0


//extra formatting
let paddedDouble = 000123.456
let oneMillion = 1_000_000
let justOverOneMillion = 1_000_000.000_000_1







//NUMERIC TYPE CONVERSION
//Integer & Floating point Conversion
let three = 3
let fltpi = 0.14159
let piValue = Double(three) + fltpi
print(piValue)
let intPi = Int(piValue)

/*Booleans
 Swift has a basic Boolean type, called Bool.
 Boolean values are referred to as logical, because they can only ever be true or false.
 Swift provides two Boolean constant values, true and false:
 */

/*TUPLES
 Tuples group multiple values into a single compound value.
 The values within a tuple can be of any type and don’t have to be of the same type as each other.
 particularly useful as the return values of functions.
 */

//a tuple of type (Int,String)
let http404Error = (404,"Not Found")


//decompossing tuple
let (statusCode,statusMsg) = http404Error
print("staus code of tuple \(statusCode)")
print("staus message of tuple \(statusMsg)")

let (stCode,_) = http404Error
print("only statusCode of tuple \(stCode)")


print("Index 0 tuple \(http404Error.0)")
print("Index 1 tuple \(http404Error.1)")



let httpsSt = (stCode:200,desc:"Ok")
print("Index 0 tuple \(httpsSt.stCode)")
print("Index 1 tuple \(httpsSt.desc)")



/*OPTIONAL
 You use optionals in situations where a value may be absent.
 An optional represents two possibilities:
 Either there is a value, and you can unwrap the optional to access that value,
 or there isn’t a value at all.
 */



var optConst : Int? = 404
//optConst is of type - optional Int


/*nil
 you set an optional variable to a valueless state by assigning it the special value nil:
 You can’t use nil with nonoptional constants and variables.
 If a constant or variable in your code needs to work with the absence of a value under certain conditions, always declare it as an optional value of the appropriate type
 it’s the absence of a value of a certain type.
 */
optConst = nil
var surveyAnswer: String?
//surveyAnswer is automatically set to nil




//If Statements and Forced Unwrapping of Optional Value
let strThree = "3"
let intValue = Int(strThree)

if intValue != nil {
    print("Int Value of String is \(intValue!)")
}else{
    print("Int Value of String is nil")
}



/*Optional Binding
 You use optional binding to find out whether an optional contains a value, and if so, to make that value available as a temporary constant or variable.
 Optional binding can be used with if and while statements to check for a value inside an optional, and to extract that value into a constant or variable, as part of a single action.
 
 if let constantName = someOptional {
 statements
 }
 
 
 */

let possibleNumber = "123"
if let actualNumber = Int(possibleNumber) {
    print("The string \"\(possibleNumber)\" has an integer value of \(actualNumber)")
}else{
    print("The string \"\(possibleNumber)\" could not be converted to an integer")
}


/*actualNumber has already been initialized with the value contained within the optional, and so there’s no need to use the ! suffix to access its value.
You can include as many optional bindings and Boolean conditions in a single if statement as you need to, separated by commas.
If any of the values in the optional bindings are nil or any Boolean condition evaluates to false, the whole if statement’s condition is considered to be false.
*/

if let firstNumber = Int("4"), let secondNumber = Int("42"), firstNumber < secondNumber && secondNumber < 100 {
    print("\(firstNumber) < \(secondNumber) < 100")
}

//is equivalient to
if let firstNumber = Int("4") {
    if let secondNumber = Int("42") {
        if firstNumber < secondNumber && secondNumber < 100  {
            print("\(firstNumber) < \(secondNumber) < 100")
        }
    }
}




//Implicitly Unwrapped Optional
//You can still treat an implicitly unwrapped Optional like a normal optional to check if it contains value

let possibleString : String? = "An optional string"
let forcedString:String = possibleString! //required !


let assumedString: String! = "An implicitly unwrapped optional string."
let implicitString : String = assumedString //! not required




/*ERROR HANDLING
 throws
 When a function encounters an error condition, it throws an error. That function’s caller can then catch the error and respond appropriately.
 try
 When you call a function that can throw an error, you prepend the try keyword to the expression.
 do catch
 A do statement creates a new containing scope, which allows errors to be propagated to one or more catch clauses.
*/
func canThrowAnError() throws {
    // this function may or may not throw an error
}

do {
    try canThrowAnError()
    // no error was thrown
} catch {
    // an error was thrown
}


/*
EX

func makeASandwich() throws {
    // ...
}

do {
    try makeASandwich()
    eatASandwich()
} catch SandwichError.outOfCleanDishes {
    washDishes()
} catch SandwichError.missingIngredients(let ingredients) {
    buyGroceries(ingredients)
}
*/

/*Assertion & Precondition
Assertions and preconditions are checks that happen at runtime.
Assertions are checked only in debug builds, but preconditions are checked in both debug and production builds
*/

let age = -3
assert(age >= 0, "A person's age can't be less than zero.")
//You pass this function an expression that evaluates to true or false and a message to display if the result of the condition is false.
//precondition(index > 0, "Index must be greater than zero.")



















































